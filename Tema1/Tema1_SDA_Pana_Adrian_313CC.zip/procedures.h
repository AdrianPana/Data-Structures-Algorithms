#ifndef PROCEDURES_H
#define PROCEDURES_H

#include "list.h"

list_t * e1(list_t * list);

list_t * e2(list_t * list);

list_t * e3(list_t * list);

list_t * u(list_t * list);

list_t * c(list_t * list);

list_t * st(list_t * list, int delta);

#endif